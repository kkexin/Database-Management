# Please complete the database setup before entering the system first.
## MySQL Settings

+ Please create a mysql database with the name ***photoms***.
+ Set the character set to ***utf8mb4***
+ The sorting rule is ***utf8mb4_general_ci***
+ Import the sql file to complete the setup.
  
## Python source code set-up
### Set up the mysql connection in the gui.py file, as in the example: 
+ ***host*** Fill in your mysql host address, or ***127.0.0.1*** if it is local.
+ If it is a virtual machine etc, please complete as appropriate.
+ Then fill in the username ***user*** and password ***passwd*** as appropriate
```
class mysql:
    def con(self):
        connect = pymysql.Connect(
            host='127.0.0.1',
            port=3306,
            user=' ',
            passwd=' ',
            db='photoms',
            charset='utf8',
            autocommit=True
        )
        return connect
```