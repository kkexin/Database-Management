import re
import sys
from datetime import datetime

import pymysql
from PyQt5.QtCore import QRegExp, pyqtSignal
from PyQt5.QtGui import QRegExpValidator, QPixmap, QImage, QPainter, QColor, QBrush, QIcon
from PyQt5.QtWidgets import QWidget, QApplication, QMessageBox, QMainWindow, QPushButton, QHBoxLayout, QTableWidgetItem, \
    QMenu, QAbstractItemView, QFileDialog, QCheckBox
import login
import untitled
import add
from PyQt5 import QtCore, Qt, QtWidgets


class mysql:
    def con(self):
        connect = pymysql.Connect(
            host='127.0.0.1',
            port=3306,
            user='root',
            passwd='abc78901',
            db='photoms',
            charset='utf8',
            autocommit=True
        )
        return connect


class loginwindow(QMainWindow, login.Ui_MainWindow, mysql):
    def __init__(self):
        super(loginwindow, self).__init__()
        self.setupUi(self)
        self.window = window()
        self.pushButton.clicked.connect(self.login)
        self.pushButton_2.clicked.connect(self.register)
        self.lineEdit.setMaxLength(6)
        self.lineEdit_4.setMaxLength(8)
        self.lineEdit_2.setMaxLength(10)
        self.lineEdit_3.setMaxLength(10)
        self.lineEdit_5.setMaxLength(10)
        reg = QRegExp('[a-zA-z0-9]+$')
        validator = QRegExpValidator(self)
        validator.setRegExp(reg)
        self.lineEdit.setValidator(validator)
        self.lineEdit_2.setValidator(validator)
        self.lineEdit_3.setValidator(validator)
        self.lineEdit_4.setValidator(validator)
        self.lineEdit_5.setValidator(validator)

    def login(self):
        con = self.con()
        cur = con.cursor()
        sql = 'call login(%s,%s)'
        sql_2 = 'SELECT uid  FROM user_info WHERE uname=%s'
        if self.lineEdit.text() == '' or self.lineEdit_2.text() == '':
            QMessageBox.information(self, "Warning", "Please check the input!")
        else:
            cur.execute(sql, [self.lineEdit.text(), self.lineEdit_2.text()])
            result = cur.fetchall()
            if result[0][0] == '1':

                self.hide()
                cur.execute(sql_2, [self.lineEdit.text()])
                result = cur.fetchall()
                self.window.uid = result[0][0]
                self.window.show()
            elif result[0][0] == '2':
                QMessageBox.information(self, "Warning", "Wrong username or password!")
            else:
                QMessageBox.information(self, "Warning", "The user does not exist!")

    def passcheck(self, password):
        if re.match("^(?:(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])).*$", password) is None:
            return False
        else:
            if len(password) >= 8:
                return True
            else:
                return False

    def register(self):
        con = self.con()
        cur = con.cursor()
        sql = 'call register(%s,%s)'
        if self.lineEdit_3.text() == '' or self.lineEdit_4.text() == '' or self.lineEdit_5.text() == '':
            QMessageBox.information(self, "Warning", "The input cannot be empty!")
        else:
            if self.passcheck(self.lineEdit_3.text()):
                if self.lineEdit_3.text() != self.lineEdit_5.text():
                    QMessageBox.information(self, "Warning", "Two inconsistent password entries!")
                else:
                    cur.execute(sql, [self.lineEdit_4.text(), self.lineEdit_3.text()])
                    con.commit()
                    result = cur.fetchall()
                    if result[0][0] == '0':
                        QMessageBox.information(self, "Tips", "This username already exists!")
                    elif result[0][0] == '1':
                        self.lineEdit_3.clear()
                        self.lineEdit_4.clear()
                        self.lineEdit_5.clear()
                        QMessageBox.information(self, "Tips", "Registration successful!")
            else:
                QMessageBox.information(self, "Warning", "The password must be a combination of 8-10 digits of English case and numbers!")


class add_window(QWidget, add.Ui_Form):
    add_data_signal = pyqtSignal(str, str)

    def __init__(self):
        super(add_window, self).__init__()
        self.setupUi(self)
        self.pushButton.clicked.connect(self.send)

    def send(self):
        name_text = self.lineEdit.text()
        caption_text = self.lineEdit_2.text()
        if name_text and caption_text:
            self.add_data_signal.emit(name_text, caption_text)
            self.lineEdit.clear()
            self.lineEdit_2.clear()
            self.close()
        else:
            QMessageBox.warning(self, 'Warning', 'Please check the input!')


class window(QWidget, untitled.Ui_Form, mysql):
    def __init__(self):
        super(window, self).__init__()
        self.pid = None
        self.a_id = None
        self.setupUi(self)
        self.uid = 10001
        self.addwindow = add_window()
        self.addwindow.add_data_signal.connect(self.accept)
        self.sql_cursor = self.con().cursor()
        self.tableWidget_refresh()
        self.tableWidget.customContextMenuRequested.connect(self.tableWidget_VTest_menu)
        self.tableWidget_2.customContextMenuRequested.connect(self.tableWidget_2_VTest_menu)
        self.tableWidget.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tableWidget_2.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tableWidget_2.horizontalHeader().setVisible(False)
        self.tableWidget_2.verticalHeader().setVisible(False)
        self.pushButton.clicked.connect(self.search_fun)
        self.pushButton_2.clicked.connect(self.comment_fun)

    def search_fun(self):
        if self.lineEdit.text() == '':
            self.tableWidget_refresh()
        else:
            sql = "select * from album_info where locate(%s,name) > 0"
            self.sql_cursor.execute(sql, self.lineEdit.text())
            result = self.sql_cursor.fetchall()
            if len(result) == 0:
                QMessageBox.information(self, "Tips", "No relevant information was retrieved!")
            else:
                rowlength = self.tableWidget.rowCount()
                for i in range(0, rowlength):
                    self.tableWidget.removeRow(0)
                for i in range(len(result)):
                    self.tableWidget.insertRow(i)
                    self.tableWidget.setItem(i, 0, QTableWidgetItem(str(result[i][0])))
                    self.tableWidget.setItem(i, 1, QTableWidgetItem(str(result[i][1])))
                    self.tableWidget.setItem(i, 2, QTableWidgetItem(str(result[i][2])))
                    self.tableWidget.setItem(i, 3, QTableWidgetItem(str(result[i][3])))
                    self.tableWidget.setItem(i, 4, QTableWidgetItem(str(result[i][4])))
                    self.tableWidget.setItem(i, 5, QTableWidgetItem(str(result[i][5])))
                    self.tableWidget.setCellWidget(i, 6, self.buttonForRow(i))
                self.tableWidget.resizeColumnsToContents()

    def comment_fun(self):
        if self.textEdit.toPlainText() == '':
            QMessageBox.information(self, "Warning", "Please check the input!")
        else:
            if self.pid is not None:
                sql = 'insert into comment_info(uid,pid,value,date) values (%s,%s, %s, %s)'
                self.sql_cursor.execute(sql, [self.uid, self.pid, self.textEdit.toPlainText(),
                                              datetime.now().strftime("%Y-%m-%d %H:%M:%S")])
                self.textEdit.clear()
                self.tableWidget_3_refresh()

    def tableWidget_3_refresh(self):
        self.sql_cursor.execute('select uid,value from comment_info where pid = %s', [self.pid])
        result = self.sql_cursor.fetchall()
        rowlength = self.tableWidget_3.rowCount()

        def getname(uid):
            self.sql_cursor.execute('select uname from user_info where uid = %s', self.uid)
            return self.sql_cursor.fetchall()[0][0]

        self.tableWidget_3.setColumnCount(1)
        for i in range(0, rowlength):
            self.tableWidget_3.removeRow(0)
        for i in range(len(result)):
            self.tableWidget_3.insertRow(i)
            self.tableWidget_3.setCellWidget(i, 0, self.comments_widget(getname(result[i][0]), result[i][1]))
            self.tableWidget_3.setColumnWidth(i, 291)
            self.tableWidget_3.setRowHeight(i, 80)
        self.tableWidget_3.verticalHeader().setHidden(True)
        self.tableWidget_3.horizontalHeader().setHidden(True)

    def comments_widget(self, value1, value2):
        widget = QtWidgets.QWidget()
        widget.setGeometry(QtCore.QRect(40, 60, 240, 80))
        widget.setObjectName("widget")
        label = QtWidgets.QLabel(widget)
        label.setGeometry(QtCore.QRect(10, 10, 150, 12))
        label.setObjectName("label")
        textBrowser = QtWidgets.QTextBrowser(widget)
        textBrowser.setGeometry(QtCore.QRect(10, 30, 240, 41))
        textBrowser.setObjectName("textBrowser")
        label.setText(value1)
        textBrowser.setText(value2)
        return widget

    def photo_widget(self, p_id, like):
        widget = QtWidgets.QWidget()
        widget.setGeometry(QtCore.QRect(380, 170, 201, 191))
        widget.setObjectName("widget")
        label = QtWidgets.QLabel(widget)
        label.setGeometry(QtCore.QRect(13, 50, 171, 131))
        label.setText("")
        label.setObjectName("label")
        label_2 = QtWidgets.QLabel(widget)
        label_2.setGeometry(QtCore.QRect(20, 20, 64, 12))
        label_2.setText(p_id)
        label_2.setObjectName("label_2")
        checkBox = QtWidgets.QCheckBox(widget)
        checkBox.setGeometry(QtCore.QRect(140, 20, 51, 16))
        checkBox.setObjectName("checkBox")
        checkBox.setText('Likes')
        if like == 1:
            checkBox.setChecked(True)
        checkBox.toggled.connect(lambda: self.like_fun(p_id, checkBox.checkState()))
        photo = self.image_get(p_id)
        label.setPixmap(photo)
        label.setScaledContents(True)
        return widget

    def tableWidget_2_refresh(self):
        def like_fun(p_id):
            sql = "SELECT * FROM like_info WHERE uid = %s and pid = %s"
            self.sql_cursor.execute(sql, [self.uid, p_id])
            result = self.sql_cursor.fetchall()
            if len(result) == 0:
                return 0
            else:
                return 1

        self.sql_cursor.execute('select p_id from photo_info where a_id  = %s', self.a_id)
        result = self.sql_cursor.fetchall()
        rowlength = self.tableWidget_2.rowCount()
        for i in range(0, rowlength):
            self.tableWidget_2.removeRow(0)
        columnCount = 2
        rowCount = len(result) // columnCount + 1
        self.tableWidget_2.setRowCount(rowCount)
        for i, item in enumerate(result):
            row = i // columnCount
            column = i % columnCount
            widget = self.photo_widget(str(item[0]), like_fun(str(item[0])))
            self.tableWidget_2.setCellWidget(row, column, widget)
            self.tableWidget_2.setColumnWidth(column, 201)
            self.tableWidget_2.setRowHeight(column, 191)

    def pic_fun(self):
        img_filter = 'Images(*.png *.jpg)'
        get_directory_path, _ = QFileDialog.getOpenFileName(self, 'Select a picture', './', f'{img_filter};;ALL(*.*)')
        if not get_directory_path:
            return None
        try:
            image = QImage(get_directory_path)
            if image.isNull():
                raise ValueError("Not in picture format!")
            with open(get_directory_path, 'rb') as file:
                binarydata = file.read()
            return binarydata
        except Exception as e:
            QMessageBox.warning(self, "Error", str(e), QMessageBox.Ok)
            return None

    def tableWidget_2_VTest_menu(self, pos):
        menu = QMenu()
        item1 = menu.addAction(u"Add a photo")
        item2 = menu.addAction(u"View details")
        item3 = menu.addAction(u"View my favourite photos")
        item4 = menu.addAction(u"Delete photo")
        action = menu.exec_(self.tableWidget_2.mapToGlobal(pos))

        def auth():
            sql = 'select * from album_info where album_id = %s and uid = %s'
            self.sql_cursor.execute(sql, [self.a_id, self.uid])
            res = self.sql_cursor.fetchall()
            if len(res) == 0:
                return False
            else:
                return True

        if action == item1:
            if self.a_id is not None:
                if auth():
                    photo = self.pic_fun()
                    if photo is not None:
                        sql = 'insert into photo_info(uid,a_id,data) values (%s,%s,%s)'
                        self.sql_cursor.execute(sql, [self.uid, self.a_id, photo])
                        self.tableWidget_2_refresh()
                else:
                    QMessageBox.information(self, 'Warning', "You do not have the right to edit other people's albums")
            pass
        elif action == item2:
            if self.tableWidget_2.rowCount() > 0:
                widget = self.tableWidget_2.cellWidget(self.tableWidget_2.currentRow(),
                                                       self.tableWidget_2.currentColumn())
                label = widget.findChild(QtWidgets.QLabel, "label_2")
                self.pid = label.text()
                photo = self.image_get(self.pid)
                self.label_4.setPixmap(photo)
                self.label_4.setScaledContents(True)
                self.tableWidget_3_refresh()

            pass
        elif action == item3:
            self.sql_cursor.execute('select pid from like_info where uid  = %s', self.uid)
            result = self.sql_cursor.fetchall()
            rowlength = self.tableWidget_2.rowCount()
            for i in range(0, rowlength):
                self.tableWidget_2.removeRow(0)
            columnCount = 2
            rowCount = len(result) // columnCount + 1
            self.tableWidget_2.setRowCount(rowCount)
            for i, item in enumerate(result):
                row = i // columnCount
                column = i % columnCount
                widget = self.photo_widget(str(item[0]), 1)
                self.tableWidget_2.setCellWidget(row, column, widget)
                self.tableWidget_2.setColumnWidth(column, 201)
                self.tableWidget_2.setRowHeight(column, 191)
            pass
        elif action == item4:
            if self.tableWidget_2.rowCount() > 0:
                if auth():
                    sql = 'delete from photo_info where p_id = %s'
                    widget = self.tableWidget_2.cellWidget(self.tableWidget_2.currentRow(),
                                                           self.tableWidget_2.currentColumn())
                    label = widget.findChild(QtWidgets.QLabel, "label_2")
                    pid = label.text()
                    self.sql_cursor.execute(sql, [pid])
                    self.tableWidget_2_refresh()
                else:
                    QMessageBox.information(self, 'Warning', "You do not have the right to edit other people's albums")
            pass

    def like_fun(self, pid, state):
        if state == Qt.Qt.Checked:
            sql = 'insert IGNORE into like_info (uid,pid) values(%s,%s)'
            self.sql_cursor.execute(sql, [self.uid, pid])
        elif state == Qt.Qt.Unchecked:
            sql = 'DELETE FROM like_info WHERE uid = %s and pid = %s'
            self.sql_cursor.execute(sql, [self.uid, pid])

    def image_get(self, pic_uid):
        sql = 'select data from photo_info where p_id = %s'
        self.sql_cursor.execute(sql, pic_uid)
        value = self.sql_cursor.fetchall()[0][0]
        photo = QPixmap()
        photo.loadFromData(value)
        return photo

    def tableWidget_VTest_menu(self, pos):
        menu = QMenu()
        item1 = menu.addAction(u"Create a new album")
        action = menu.exec_(self.tableWidget.mapToGlobal(pos))
        if action == item1:
            self.addwindow.setWindowModality(2)
            self.addwindow.show()

    def com_detail(self, bid):
        self.a_id = self.tableWidget.item(bid, 0).text()
        self.tableWidget_2_refresh()
        self.tableWidget_refresh()
        self.tabWidget.setCurrentIndex(1)
        pass

    def com_delete(self, bid):
        a_id = self.tableWidget.item(bid, 0).text()
        sql = 'select * from album_info where album_id = %s and uid = %s'
        self.sql_cursor.execute(sql, [a_id, self.uid])
        res = self.sql_cursor.fetchall()
        if len(res) == 0:
            QMessageBox.information(self, 'Warning', "You do not have the right to delete other people's albums")
        else:
            self.sql_cursor.execute('delete from album_info WHERE album_id = %s', a_id)
            self.tableWidget_refresh()
            self.tableWidget_2_refresh()
            self.tableWidget_3_refresh()
        pass

    def buttonForRow(self, bid):
        widget = QWidget()
        buyBtn = QPushButton('View details')
        buyBtn.clicked.connect(lambda: self.com_detail(bid))
        viewBtn = QPushButton('Delete')
        viewBtn.clicked.connect(lambda: self.com_delete(bid))
        hLayout = QHBoxLayout()
        hLayout.addWidget(viewBtn)
        hLayout.addWidget(buyBtn)
        hLayout.setContentsMargins(5, 2, 5, 2)
        widget.setLayout(hLayout)
        return widget

    def tableWidget_refresh(self):
        self.sql_cursor.execute('select * from album_info')
        result = self.sql_cursor.fetchall()
        rowlength = self.tableWidget.rowCount()
        for i in range(0, rowlength):
            self.tableWidget.removeRow(0)
        for i in range(len(result)):
            self.tableWidget.insertRow(i)
            self.tableWidget.setItem(i, 0, QTableWidgetItem(str(result[i][0])))
            self.tableWidget.setItem(i, 1, QTableWidgetItem(str(result[i][1])))
            self.tableWidget.setItem(i, 2, QTableWidgetItem(str(result[i][2])))
            self.tableWidget.setItem(i, 3, QTableWidgetItem(str(result[i][3])))
            self.tableWidget.setItem(i, 4, QTableWidgetItem(str(result[i][4])))
            self.tableWidget.setItem(i, 5, QTableWidgetItem(str(result[i][5])))
            self.tableWidget.setCellWidget(i, 6, self.buttonForRow(i))
        self.tableWidget.resizeColumnsToContents()

    def accept(self, text, text_1):
        dateformat = "%Y-%m-%d %H:%M:%S"
        date = datetime.now().strftime(dateformat)
        sql = 'insert into album_info (uid,name,date,caption,pohtos_number) values (%s,%s,%s,%s,%s)'
        self.sql_cursor.execute(sql, [self.uid, text, date, text_1, 0])
        self.tableWidget_refresh()


if __name__ == "__main__":
    QtCore.QCoreApplication.setAttribute(Qt.Qt.AA_EnableHighDpiScaling)
    app = QApplication(sys.argv)
    window = loginwindow()
    window.show()
    sys.exit(app.exec_())
