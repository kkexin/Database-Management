/*User activity*/
DECLARE @NumPhotos INT;
DECLARE @NumComments INT;
DECLARE @TotalContribution INT;

SELECT u.UserId, u.FirstName, u.LastName, 
     COUNT(DISTINCT p.PhotoId) + COUNT(DISTINCT c.CommentId) AS TotalContribution
FROM Users u
LEFT JOIN Photos p ON u.UserId = p.UserId
LEFT JOIN Comments c ON u.UserId = c.UserId
GROUP BY u.UserId, u.FirstName, u.LastName
ORDER BY Contribution DESC
LIMIT 10;
