SELECT u.FirstName, u.LastName, COUNT(*) AS NumComments
FROM comments c
JOIN users u ON c.UserId = u.UserId
WHERE Likes '%<text>%'
GROUP BY u.UserId, u.FirstName, u.LastName
ORDER BY NumComments DESC;

