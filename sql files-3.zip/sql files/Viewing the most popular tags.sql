/*Viewing the most popular tags*/
SELECT t.name AS TagName, COUNT(*) AS PhotoCount
FROM Tags t
JOIN PhotoTags pt ON t.id = pt.TagId
GROUP BY t.name
ORDER BY COUNT(*) DESC;
