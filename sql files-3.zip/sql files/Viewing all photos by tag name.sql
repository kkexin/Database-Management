/*Viewing all photos by tag name*/
SELECT p.PhotoId, p.PhotoName, p.UserId, a.albumName, t.TagName 
FROM photos p 
INNER JOIN albums a ON p.album_id = a.album_id 
INNER JOIN photo_tags pt ON p.photo_id = pt.photo_id 
INNER JOIN Tags t ON pt.tag_id = t.tag_id 
WHERE t.tag_name = @tag_name;
