/*Friend recommendation*/
DECLARE @user_id, INT;

SELECT f1.UserId, u1.FirstName, u1.LastName, COUNT(*) AS CommonFriends
FROM friends f2
INNER JOIN friends f1 ON f2.FriendId = f1.UserId
INNER JOIN users u ON f1.UserId = u.UserId
WHERE f2.UserId = @user_id AND f1.UserId <> @user_id AND f1.UserId NOT IN 
(
    SELECT FriendId FROM friends WHERE UserId = @user_id
)
GROUP BY f1.UserId, u2.FirstName, u2.LastName
ORDER BY CommonFriends DESC;

