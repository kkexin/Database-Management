DECLARE @photo_id, INT;
DECLARE @user_id, INT;

INSERT INTO likes (PhotoId, UserId)
VALUES (@photo_id, @user_id);

UPDATE photos
SET NumLikes = NumLikes + 1
WHERE PhotoId = @photo_id;

SELECT u.UserId, u.FirstName, u.LastName
FROM users u
INNER JOIN likes l ON u.UserId = l.UserId
WHERE l.PhotoId = @photo_id;

COMMIT;


