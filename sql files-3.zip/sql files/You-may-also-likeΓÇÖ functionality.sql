/*‘You-may-also-like’ functionality*/
SELECT p.PhotoId, p.PhotoName, COUNT(*) AS matches, COUNT(DISTINCT t.TagName) AS TagNum
FROM photos p
JOIN PhotoTags pt ON p.PhotoId = pt.PhotoId
JOIN tags t ON t.TagName = pt.TagName
WHERE t.TagName IN 
(
    SELECT t.TagName
    FROM photos p
    JOIN PhotoTags pt ON p.PhotoId = pt.PhotoId
    JOIN tags t ON t.TagName = pt.TagName
    WHERE p.UserId = @user_id
    GROUP BY pt.TagName
    ORDER BY COUNT(*) DESC
    LIMIT 5
)
AND p.UserId != @user_id
GROUP BY p.PhotoId, p.PhotoName
ORDER BY matches DESC, TagNum ASC
LIMIT 10;

