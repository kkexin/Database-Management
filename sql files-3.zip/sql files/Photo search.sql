/*Photo search*/
SELECT p.imgdata, GROUP_CONCAT(t.name) AS TagName
FROM Photos p
JOIN PhotoTags pt ON p.id = pt.PhotoId
JOIN Tags t ON pt.TagId = t.id
WHERE MATCH (t.name) AGAINST ('input' IN BOOLEAN MODE)
GROUP BY p.id
