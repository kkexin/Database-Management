/*Becoming a registered user.*/ 
DECLARE @new_id INT;
SET @new_id = new_id;

INSERT INTO Users (UserId, FirstName, LastName, Hometown, Gender, DateOfBirth, Email,  HashedPassword)
VALUES (@new_userid, 'first_name', 'last_name', 'hometown', 'gender', 'date_of_birth',   'email', 'hashed_password');
SELECT COUNT(*) FROM Users WHERE Email = 'email';
