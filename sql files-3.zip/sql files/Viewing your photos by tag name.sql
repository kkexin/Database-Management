
/*Viewing your photos by tag name*/
SELECT p.*, t.name AS TagName
FROM photos p
JOIN PhotoTags pt ON p.id = pt.PhotoId
JOIN Tags t ON pt.TagId = t.id
WHERE p.user_id = user_id AND t.name = 'tag_name';

