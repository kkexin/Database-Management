/*Logging In/Out.*/
DECLARE @email VARCHAR(100);
DECLARE @password VARCHAR(100);

SELECT COUNT(*) INTO @num_users
FROM users
WHERE email = @email AND password = @password;

-- Log in
IF @num_users = 1
BEGIN
UPDATE users
SET is_logIn = 1
WHERE email = @email;
END

-- Log out
BEGIN
UPDATE users
SET is_logIn = 0
WHERE email = @email;
END
