/*Photo and album creating.*/
BEGIN;

INSERT INTO albums (album_name, user_id) 
VALUES (@user_id, @album_name);

INSERT INTO photos (album_id, user_id, photo_name)
VALUES (LAST_INSERT_ID(), @user_id, @photo_name);

DELETE FROM photos WHERE photo_id = @photo_id AND user_id = @user_id;
DELETE FROM likes WHERE photo_id = @photo_id;
DELETE FROM comments WHERE photo_id = @photo_id;
DELETE FROM albums WHERE album_id = @album_id AND user_id = @user_id;
DELETE FROM photos WHERE album_id = @album_id;
DELETE FROM likes WHERE photo_id IN (SELECT photo_id FROM photos WHERE album_id = @album_id);
DELETE FROM comments WHERE photo_id IN (SELECT photo_id FROM photos WHERE album_id = @album_id);

COMMIT;
