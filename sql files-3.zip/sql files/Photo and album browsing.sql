DECLARE @album_id INT;
DECLARE @user_id INT;

SELECT * FROM photos WHERE is_public = 1;
SELECT * FROM albums WHERE is_public = 1;
SELECT * FROM photos WHERE album_id = @album_id;
SELECT * FROM albums WHERE user_id = @user_id;
SELECT * FROM photos WHERE user_id = @user_id;
SELECT * FROM photos WHERE album_id = @album_id AND user_id = @user_id;
SELECT * FROM photos WHERE is_public = 1 OR user_id = @user_id;
SELECT * FROM albums WHERE is_public = 1 OR user_id = @user_id;
