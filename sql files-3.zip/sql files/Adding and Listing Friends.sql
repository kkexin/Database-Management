/*Adding and Listing Friends.*/ 
DECLARE @user_id INT;
DECLARE @friend_id INT;
DECLARE @search_term VARCHAR(100);

INSERT INTO Friends (UserId, FriendId, FriendDate)
VALUES (@user_id, @friend_id, GETDATE());

SELECT u.UserId, u.FirstName, u.LastName, u.Hometown, u.Gender, u.DateOfBirth, u.Email, 
FROM Friends f
JOIN Users u ON f.FriendId = u.UserId
WHERE f.UserId = @user_id
UNION
SELECT u.UserId, u.FirstName, u.LastName, u.Hometown, u.Gender, u.DateOfBirth, u.Email,
FROM Friends f
JOIN Users u ON f.UserId = u.UserId
WHERE f.FriendId = @user_id;

SELECT u.UserId, u.FirstName, u.LastName, COUNT(DISTINCT p.PhotoId) + COUNT(DISTINCT c.CommentId) AS Contribution
FROM Users u
LEFT JOIN Photos p ON u.UserId = p.UserId
LEFT JOIN Comments c ON u.UserId = c.UserId
GROUP BY u.UserId, u.FirstName, u.LastName
ORDER BY Contribution DESC
LIMIT 10;
