DECLARE comment_id INT;
DECLARE photo_id INT;
DECLARE user_id INT;
DECLARE text VARCHAR(100);
DECLARE date DATETIME;

INSERT INTO comments (ComentId, PhotoId, UserId, Text, Date) 
VALUES (@comment_id, @photo_id, @user_id, @text, @date);

UPDATE users
SET ContributionScore = ContributionScore + 1
WHERE UserId = @user_id;
SELECT UserId, FirstName, LastName, ContributionScore
FROM users
ORDER BY ContributionScore DESC
LIMIT 10; 
COMMIT;

